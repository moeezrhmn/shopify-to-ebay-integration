


<?php $__env->startSection('content'); ?>
    <div class=" d-flex align-items-center" style="min-height: 90vh;">
        <div class="container">
            <div class="row text-center mb-4">
                <div class="col">
                    <h3> Create Item Specific </h3>
                </div>
            </div>
            <div class="row justify-content-center  ">
                <div class="col-md-10">
                    <div class="form-box p-3 border rounded">
                        <form action="" class="row">
                            <div class="col mb-3">
                                <label for="aspect_name"> Aspect name </label>
                                <input id="aspect_name" type="text" name="aspect_name" class="form-control">
                            </div>
                            <div class="col mb-3">
                                <label for="aspect_name"> Aspect name </label>
                                <input id="aspect_name" type="text" name="aspect_name" class="form-control">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Maxenius\shopify_ebay_sync\resources\views/item_specifics/create.blade.php ENDPATH**/ ?>