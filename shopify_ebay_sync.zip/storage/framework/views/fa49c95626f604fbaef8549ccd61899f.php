


<?php $__env->startSection('content'); ?>
<style>
 
    .log-entry {
        word-wrap: break-word;
        word-break: break-all;
        padding: 5px 0;
        border-bottom: 1px solid #ddd;
    }
</style>

<div class="container my-5 ">
    <div class="row ">
        <h2> <?php echo e($log_name); ?> </h2>
    </div>
    <div class="row  my-3">
        <?php if(session('message')): ?>
        <div class="alert alert-primary" role="alert">
            <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col">
            <div class="border bg-dark text-white rounded p-3">
                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="log-entry py-2" style="border-bottom: 1px solid #ddd;">
                    <?php echo e($log); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Maxenius\shopify_ebay_sync\resources\views/logs/index.blade.php ENDPATH**/ ?>