<?php $__env->startSection('content'); ?>
    <div class=" d-flex align-items-start pt-5" style="min-height: 90vh;">
        <div class="container pb-5 mb-5 ">
            <div class="row mb-3">
                <div class="col">
                    <h3> Shopify to eBay Syncronized Products </h3>
                </div>

            </div>
            <div class="row">
                <div class="col">
                    <div class="p-3 border rounded">
                        <table class="table" id="item_source_table">
                            <thead>
                                <th> Shopify Product ID </th>
                                <th> Inventory Item ID </th>
                                <th> Ebay Item ID </th>
                                <th> Last Stock </th>
                                <th> Template Applied </th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $item_sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td> <?php echo e($item->shopify_product_id); ?> </td>
                                        <td> <?php echo e($item->inventory_item_id); ?> </td>
                                        <td> <?php echo e($item->ebay_item_id); ?> </td>
                                        <td> <?php echo e($item->last_stock); ?> </td>
                                        <td> 
                                            <span class="badge text-bg-<?php echo e($item->template_applied ? 'success' : 'danger'); ?> ">
                                                <?php echo e($item->template_applied ? 'Applied' : 'Not Applied'); ?>

                                            </span>
                                         </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/2.1.2/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.1.2/js/dataTables.bootstrap5.js"></script>

    <script>
        const table = new DataTable('#item_source_table', {
            autoWidth: false,
            columnDefs: [{
                    orderable: false,
                    targets: 0
                },
                {
                    orderable: false,
                    targets: 1
                },
                {
                    orderable: false,
                    targets: 2
                },
            ]
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Maxenius\shopify_ebay_sync\resources\views/welcome.blade.php ENDPATH**/ ?>