


<?php $__env->startSection('content'); ?>
    <div class=" d-flex align-items-start pt-5" style="min-height: 90vh;">
        <div class="container pb-5 mb-5 ">
            <div class="row mb-3">
                <div class="col">
                    <h3> Ebay </h3>
                </div>
                <div class="col">
                    <?php if(!empty(session('message'))): ?>
                    <div class="alert alert-info" role="alert">
                        <?php echo e(session('message')); ?>

                      </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-12 mb-3">
                    <div class="p-3 border rounded">
                        <h4>Update item:</h4>
                        <form action="<?php echo e(route('ebay.complete_item_update')); ?>" class="row pt-4"  method="post">
                            <?php echo csrf_field(); ?>
                            <div class="col-6">
                                <input type="text" name="item_id" placeholder="paste ebay item id here" class="form-control">
                            </div>
                            <div class="col-6">
                                <button type="submit" class="btn btn-dark" > Update</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-12 mb-3">
                    <div class="p-3 border rounded">
                        <h4>Update title:</h4>
                        <form  action="<?php echo e(route('ebay.title_update')); ?>" class="row pt-4"  method="post">
                            <?php echo csrf_field(); ?>
                            <div class="col-6">
                                <input type="text" name="item_id" placeholder="paste ebay item id here" class="form-control">
                            </div>
                            <div class="col-6">
                                <button type="submit" class="btn btn-dark" > Update</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-12 mb-3">
                    <div class="p-3 border rounded">
                        <h4>Update Item specifics:</h4>
                        <form action="<?php echo e(route('ebay.item_specifics_update')); ?>"  class="row pt-4"  method="post">
                            <?php echo csrf_field(); ?>
                            <div class="col-6">
                                <input type="text"  name="item_id" placeholder="paste ebay item id here" class="form-control">
                            </div>
                            <div class="col-6">
                                <button type="submit" class="btn btn-dark" > Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Maxenius\shopify_ebay_sync\resources\views/ebay/index.blade.php ENDPATH**/ ?>