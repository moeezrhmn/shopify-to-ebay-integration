


<?php $__env->startSection('page_title'); ?>
    Category Mapping
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<h1> Category mapping </h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Maxenius\shopify_ebay_sync\resources\views/category/view.blade.php ENDPATH**/ ?>