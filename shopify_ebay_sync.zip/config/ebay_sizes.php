<?php


return [

    'xxsmall' => 'XXS',
    'xsmall' => 'XS',
    'small' => 'S',
    'medium' => 'M',
    'large' => 'L',
    'xlarge' => 'XL',
    'xxlarge' => '2XL',
    'xxxlarge' => '3XL',
    'xxxxlarge' => '4XL',
    'xxxxxlarge' => '5XL',
    'xxxxxxlarge' => '6XL',
];