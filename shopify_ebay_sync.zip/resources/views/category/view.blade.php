@extends('layouts.app')


@section('page_title')
    Category Mapping
@endsection

@section('content')
    
<h1> Category mapping </h1>

@endsection